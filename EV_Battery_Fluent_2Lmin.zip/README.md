# Fluent steady-state case: 2 L/min (design baseline)

Group 11 ME3331 battery-cooling study. This ZIP includes the matching `Baseline_2Lmin_5W.cas.h5` case and `Baseline_2Lmin_5W.dat.h5` solution data files for ANSYS Fluent 2026 R1 or a compatible version.

Assumptions: 46 cells × 5 W per cell, 25°C coolant inlet, steady-state conjugate heat transfer. This is a preliminary single-mesh calculation and not a validated thermal design.

Load the case and data together. The files are provided for engineering reproducibility; proprietary ANSYS software is not included.

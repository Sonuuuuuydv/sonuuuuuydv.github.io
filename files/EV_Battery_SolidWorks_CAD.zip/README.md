# Group 11 — EV Battery Liquid-Cooling CAD

Source parts and assemblies for the 46-cell liquid-cooled battery module developed in ME3331 Heat Transfer, Fall 2026. Group 11 contributors: Sonu K Yadav and Anshul Thapa.

## Open the model

- For a neutral CAD exchange format, open `CFD_Final Battery_Cooling_Plate_Assembly.STEP` in a STEP-compatible CAD package.
- For the editable native model, open `Final Battery_Cooling_Plate_Assembly.SLDASM` in SolidWorks with the `.SLDPRT` and other `.SLDASM` files in this folder. If SolidWorks asks to locate references, point it to this folder.
- Part names follow the original student project, including the `G11_` prefix.

The CAD model is an educational design study, not a manufacturing-ready battery pack. The mesh, solver files, and result assumptions are described separately in the project portfolio and downloadable Fluent datasets.
